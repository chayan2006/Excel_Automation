"""Excel automation package."""
